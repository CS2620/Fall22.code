# Fall2022.Lambda

Reference implementation for CSCI 2620 - Computer Graphics: Image Processing, Fall 2022


