package ip;

public class Triple {
  int r;
  int g;
  int b;

  public Triple(){
    this.r = 0;
    this.g = 0;
    this.b = 0;
  }

  public Triple(int r, int g, int b){
    this.r = r;
    this.g = g;
    this.b = b;
  }

}
