package helps.lambdas;

public interface IIntToInt {
  int run(int i);
}
