package helps.lambdas;
import ip.Layer;

public interface ILayerLambda {
  Layer lambda(Layer layer);
}
