package helps.lambdas;

public interface IFloatToFloat {
  float run(float value);
  
}
