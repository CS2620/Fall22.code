package helps.lambdas;

import ip.IP;
public interface IIPLambda {
  IP lambda(IP ip);
}
