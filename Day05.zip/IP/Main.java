
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Main {

  public static void main(String[] args) {

    new IP("download.jpg")
    .rotate(10, true)
    
    .save("done.png");
    //new IP("download.jpg").rotate(10, false).save("done2.png");

    // System.out.println(interpolate(1,2,0));
    // System.out.println(interpolate(1,2,1));
    // System.out.println(interpolate(1,2,.5f));
    // System.out.println(interpolate(100,212,.1f));

  }

  public static float interpolate(float one, float two, float percent){

    float value = (1-percent)*one+(percent)*two;


    return value;
  }
}