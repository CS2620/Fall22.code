package ip;

public class OCRFeatures {
  String file = "";
  public float distanceTo(OCRFeatures myOCR) {
    return (float)Math.random();
  }
}
