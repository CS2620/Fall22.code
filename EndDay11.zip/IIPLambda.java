public interface IIPLambda {
  IP lambda(IP ip);
}
