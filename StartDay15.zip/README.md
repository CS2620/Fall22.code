# Fall2022.CodePrep
Where I keep code that isn't ready to be unleashed on innocent students yet.
