import java.awt.Color;

public interface IColorToColor {
  Color toColor(Color inColor);
}
