public interface ILayerLambda {
  Layer lambda(Layer layer);
}
