public interface IBlend {
  int blend(int a, int b);
}
