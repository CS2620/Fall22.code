public interface IBlendColor {
  int blend(int a, int b, int k1, int k2);
}
