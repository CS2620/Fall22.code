import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class IP {

    BufferedImage bufferedImage;

    public IP(String filename){
        try {
            this.bufferedImage = ImageIO.read(new File(filename));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public IP toGrayscale(){
        for(int y = 0; y < bufferedImage.getHeight(); y++){
            for(int x = 0; x < bufferedImage.getWidth(); x++){
               
                Color color = new Color(bufferedImage.getRGB(x, y));
                int average = (color.getRed() + color.getGreen() + color.getBlue())/3;
                Color newColor = new Color(average, average, average);

                bufferedImage.setRGB(x, y, newColor.getRGB());
            }
        }
        
        
        
        return this;
    }

    public IP rotate180(){
        BufferedImage intermediate = new BufferedImage(bufferedImage.getWidth(), bufferedImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for(int y = 0; y < bufferedImage.getHeight(); y++){
            for(int x = 0; x < bufferedImage.getWidth(); x++){
               
                Color color = new Color(bufferedImage.getRGB(x, y));
                
                // int halfWidth = bufferedImage.getWidth()/2;
                // int halfHeight = bufferedImage.getHeight()/2;

                int x1 = bufferedImage.getWidth() - x - 1;
                int y1 = bufferedImage.getHeight() - y - 1;

                
                intermediate.setRGB(x1, y1, color.getRGB());
            }
        }

        bufferedImage = intermediate;
        return this;
    }

    public IP rotate90(){
        BufferedImage intermediate = new BufferedImage(bufferedImage.getHeight(), bufferedImage.getWidth(), BufferedImage.TYPE_INT_ARGB);
        for(int y = 0; y < bufferedImage.getHeight(); y++){
            for(int x = 0; x < bufferedImage.getWidth(); x++){
               
                Color color = new Color(bufferedImage.getRGB(x, y));
                
                int y1 = bufferedImage.getWidth() - x - 1;
                int x1 = bufferedImage.getHeight() - y - 1;

                
                intermediate.setRGB(x1, y1, color.getRGB());
            }
        }

        bufferedImage = intermediate;
        return this;
    }

    public IP translateForward(int dx, int dy){
        int bw = bufferedImage.getWidth();
        int bh = bufferedImage.getHeight();
        BufferedImage intermediate = new BufferedImage(bw, bh, BufferedImage.TYPE_INT_ARGB);


        Graphics g = intermediate.getGraphics();
        g.setColor(Color.CYAN);
        g.fillRect(0,0,bw,bh);
        
        for(int y = 0; y < bh; y++){
            for(int x = 0; x < bw; x++){
               
                Color color = new Color(bufferedImage.getRGB(x, y));
                
                int y1 = y + dy;
                int x1 = x + dx;

                if( x1 >= bw || y1 >= bh || x1 < 0 || y1 < 0)
                    continue;

                
                intermediate.setRGB(x1, y1, color.getRGB());
            }
        }

        bufferedImage = intermediate;
        return this;
    }

    public IP translate(int dx, int dy){
        int bw = bufferedImage.getWidth();
        int bh = bufferedImage.getHeight();
        BufferedImage intermediate = new BufferedImage(bw, bh, BufferedImage.TYPE_INT_ARGB);


        Graphics g = intermediate.getGraphics();
        g.setColor(Color.CYAN);
        g.fillRect(0,0,bw,bh);
        
        for(int y = 0; y < bh; y++){
            for(int x = 0; x < bw; x++){
                int originalX = x - dx;
                int originalY = y - dy;
               

                Color color;
                if( originalX >= bw || originalY >= bh || originalX < 0 || originalY < 0)
                    color = Color.MAGENTA;

                else
                    color = new Color(bufferedImage.getRGB(originalX, originalY));
                
                intermediate.setRGB(x, y, color.getRGB());
            }
        }

        bufferedImage = intermediate;
        return this;
    }

    public IP save(String filename){
        try {
            ImageIO.write(bufferedImage, "PNG", new File(filename));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally{
            return this;
        }

    }
    
}
