
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Main {

  public static void main(String[] args) {

    new IP("download.jpg").translate(100, 100).save("done.png");
  }
}